



let P_class_1=document.querySelector(".da")
P_class_1.onfocus=function(){
  const lists=["time_1","time_2","time_3"];
  for(let i=0;i<lists.length;i++){
  var input=document.getElementById(lists[i]);
  var current_time=new Date().toISOString().slice(0,16);
  input.value=current_time;}
};

let list = document.querySelectorAll(".navigation li");

function activeLink() {
  list.forEach((item) => {
    item.classList.remove("hovered");
  });

  this.classList.add("hovered");
}

list.forEach((item) => item.addEventListener("mouseover", activeLink));


let toggle = document.querySelector(".toggle");
let navigation = document.querySelector(".navigation");
let main = document.querySelector(".main");
let home = document.querySelector(".home");
let contain = document.querySelector(".contain");
let recipt_1=document.querySelector(".recipt_1");
let recipt_2=document.querySelector(".recipt_2");
let recipt_3=document.querySelector(".recipt_3");
let reports=document.querySelector(".reports");
let users=document.querySelector(".users");
let admin=document.querySelector(".admin");
let modal_users=document.querySelector(".modal");
let branch=document.querySelector(".branch")
let main_p=document.getElementById("main_p")
let id_input=document.querySelector(".id_")
let name_input=document.querySelector(".name_")
let password_input=document.querySelector(".password_")
let role_input=document.querySelector(".role_")


toggle.onclick = function () {
  home.classList.toggle("available_re_1");
  recipt_1.classList.toggle("available_re_1");
  recipt_2.classList.toggle("available_re_1");
  recipt_3.classList.toggle("available_re_2");
  reports.classList.toggle("available_re_1");
  users.classList.toggle("available_re_1");
  admin.classList.toggle("available_re_2");
  contain.classList.toggle("available");
  navigation.classList.toggle("active");
  main.classList.toggle("active");
};

function home_fun(){
  main_p.textContent="الرئيسية"
  home.style.display="block";
  recipt_1.style.display="none";
  recipt_2.style.display="none";
  recipt_3.style.display="none";
  reports.style.display="none";
 users.style.display="none";
  admin.style.display="none";


  }
  function recipt_1_fun(){
    main_p.textContent="سند الصرف"
    home.style.display="none";
    recipt_1.style.display="block";
    recipt_2.style.display="none";
    recipt_3.style.display="none";
    reports.style.display="none";
   users.style.display="none";
    admin.style.display="none";}
  function recipt_2_fun(){
    main_p.textContent="سندالقبض"
    home.style.display="none";
    recipt_1.style.display="none";
    recipt_2.style.display="block";
    recipt_3.style.display="none";
    reports.style.display="none";
   users.style.display="none";
    admin.style.display="none";
  }
  function recipt_3_fun(){
    main_p.textContent="سند  تحصيل"
    home.style.display="none";
    recipt_1.style.display="none";
    recipt_2.style.display="none";
    recipt_3.style.display="block";
    reports.style.display="none";
   users.style.display="none";
    admin.style.display="none";
  }
  function reports_fun(){
    main_p.textContent="التقارير"
    home.style.display="none";
  recipt_1.style.display="none";
  recipt_2.style.display="none";
  recipt_3.style.display="none";
  reports.style.display="block";
 users.style.display="none";
  admin.style.display="none";
  }
  function users_fun(){
    main_p.textContent="إدارة المستخدم"
    // branch.src="static/image/user.png"
    home.style.display="none";
    recipt_1.style.display="none";
    recipt_2.style.display="none";
    recipt_3.style.display="none";
    reports.style.display="none";
   users.style.display="block";
    admin.style.display="none";
  }
  
  function admin_fun(){
    main_p.textContent="صلاحيات النظام"
    home.style.display="none";
    recipt_1.style.display="none";
    recipt_2.style.display="none";
    recipt_3.style.display="none";
    reports.style.display="none";
   users.style.display="none";
    admin.style.display="block";
  }




  function edit_user(the_id){
    modal_users.style.display="block"; 
    var the_id_=parseInt(the_id)+1;
    id_input.value=the_id_;


  
  
  }


function hideWarning(){
  const warningContainer = document.getElementById('warningContainer');
      warningContainer.classList.remove('show');

}

  function close_edit_user(){
    modal_users.style.display="none"; 
    id_input.value="";
    name_input.value="";
    password_input.value="";
    role_input.valu=""; }

function edit_users(id,name,pass,role) {

modal_users.style.display="block";  

id_input.value=id;
name_input.value=name;
password_input.value=pass;
role_input.valu=role;
}
function edit_user() {

modal_users.style.display="block";  


}
