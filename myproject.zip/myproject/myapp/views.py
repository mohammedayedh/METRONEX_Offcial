from django.shortcuts import render ,redirect , get_object_or_404
from django.http import HttpResponse
from .models import *
from django.contrib import messages
from django.db.models import Sum
from telebot import TeleBot
import locale
import datetime
from datetime import date
locale.setlocale(locale.LC_TIME, 'ar')



def login(request):
    context={"branchs":["Main","Mathbah","Al-thawra","Haddah"]}
    maintaince = settings.objects.first()
    if maintaince.maintenance_status == 'yes':
        return render(request, 'maintain.html')
    if request.method == 'POST':
        username  =  request.POST['username']
        password  =  request.POST['password']
        branche  =  request.POST['branch']
        print(branche)
        user_admin  =  users.objects.filter(name = username, branch = branche, password = password, roles = 'admin')
        user_super  =  users.objects.filter(name = username, password = password , branch = branche, roles = 'supervisor')
        user_normal  =  users.objects.filter(name = username, password = password , branch = branche, roles = 'user')
        log_tru  =  False

        if user_admin.exists():
            request.session['log_tru']  =  True
            username  =  request.POST['username']
            request.session['username']  =  username
            return redirect('home')
        elif user_super.exists():

            request.session['username']  =  username
            request.session['log_tru']  =  True
            return redirect('home')
        elif user_normal.exists():
            request.session['log_tru']  =  True
            request.session['username']  =  username
            return redirect('home')
        else:
            messages.error(request,message = 'هناك خطأ في معلومات تسجيل الدخول')
            return redirect('login')

    return render(request, 'login.html',context)


def logout(request):
    request.session['log_tru']  =  False
    return redirect('login')




def admin_home(request):
    
    if request.method  ==  'POST':
        form_type  =  request.POST.get('form_type')
        if form_type  ==  'manage_user':
            passwords=request.POST['new_pass']
            global usernames
            try:
                # التحقق مما إذا كان المستخدم موجودًا في قاعدة البيانات
                user_data = users.objects.get(name=usernames)
                
                # تحديث بيانات المستخدم
                
                user_data.password = passwords
                user_data.save()
                
                messages.success(request, 'تم التحديث بنجاح')
            except users.DoesNotExist:
                pass
        if form_type  ==  'recipt_1':
            name  =  request.POST['recipt_1_name']
            mony  =  request.POST['recipt_1_mony']
            data_time = request.POST['recipt_1_data_time']
            details = request.POST['recipt_1_details']
            user = request.POST['recipt_1_user']
            user_data_r_1  =  recipt_1(
            name = name,
            mony = mony,
            data_time = data_time,
            details = details,
            user = user,           
            )
            try:
                user_data_r_1.save()
                request.session['name_r1']  =  name
                request.session['mony_r1']  =  mony
                request.session['data_time_r1']  =  data_time
                request.session['details_r1']  =  details
                request.session['user_r1']  =  user
                messages.success(request, 'تم الحفظ بنجاح')
                return redirect( 'print_recipt_1') ######################################
            except:
                messages.error(request, 'تأكد من صحة وإكتمال البيانات -  حدث خطأ أثناء الحفظ')
            
            return redirect(request.META['HTTP_REFERER'])
        elif form_type  ==  'recipt_2':
            name  =  request.POST['recipt_2_name']
            mony  =  request.POST['recipt_2_mony']
            data_time = request.POST['recipt_2_data_time']
            details = request.POST['recipt_2_details']
            user = request.POST['recipt_2_user']
            user_data_r_2  =  recipt_2(
            name = name,
            mony = mony,
            data_time = data_time,
            details = details,
            user = user,           
            )
            try:
                user_data_r_2.save()
                messages.success(request, 'تم الحفظ بنجاح')
                request.session['name_r2']  =  name
                request.session['mony_r2']  =  mony
                request.session['data_time_r2']  =  data_time
                request.session['details_r2']  =  details
                request.session['user_r2']  =  user
                return redirect( 'print_recipt_2') ######################################
            except:
                messages.error(request, 'تأكد من صحة وإكتمال البيانات -  حدث خطأ أثناء الحفظ')
            return redirect(request.META['HTTP_REFERER'])
        elif form_type  ==  'recipt_3':
            amount1  =  request.POST['amount1']
            description1  =  request.POST['description1']
            amount2  =  request.POST['amount2']
            description2  =  request.POST['description2']
            amount3  =  request.POST['amount3']
            description3  =  request.POST['description3']
            amount4  =  request.POST['amount4']
            description4  =  request.POST['description4']
            amount5 =  request.POST['amount5']
            description5  =  request.POST['description5']
            amount6  =  request.POST['amount6']
            description6  =  request.POST['description6']
            amount7  =  request.POST['amount7']
            description7  =  request.POST['description7']
            amount8  =  request.POST['amount8']
            description8  =  request.POST['description8']
            net_mony  =  request.POST['net_mony']
            out_mony  =  request.POST['out_mony']
            total_mony  =  request.POST['total_mony']
            date  =  request.POST['date']
            name  =  request.POST['name']
            user  =  request.POST['user_r']
            user_data_r_3  =  recipt_3(
            net_mony = net_mony,
            out_mony = out_mony,
            total_mony = total_mony,         
            date = date,
            name = name,
            user = user,
            amount1 = amount1,
            description1 = description1,
            amount2 = amount2,
            description2 = description2,
            amount3 = amount3,
            description3 = description3,
            amount4 = amount4,
            description4 = description4,
            amount5 = amount5,
            description5 = description5,
            amount6 = amount6,
            description6 = description6,
            amount7 = amount7,
            description7 = description7,
            amount8 = amount8,
            description8 = description8,)
            try:
                user_data_r_3.save()
                messages.success(request, 'تم الحفظ بنجاح')
                context={
                'net_mony': str(net_mony),
                'out_mony': str(out_mony),
                'total_mony': str(total_mony),
                'date': str(date),
                'name': str(name),
                'user': str(user),
                'amount1': str(amount1),
                'description1': str(description1),
                'amount2': str(amount2),
                'description2': str(description2),
                'amount3': str(amount3),
                'description3': str(description3),
                'amount4': str(amount4),
                'description4': str(description4),
                'amount5': str(amount5),
                'description5': str(description5),
                'amount6': str(amount6),
                'description6': str(description6),
                'amount7': str(amount7),
                'description7': str(description7),
                'amount8': str(amount8),
                'description8': str(description8),}
                return render(request, 'print_recipt_3.html',context)
            except:
                messages.error(request, 'تأكد من صحة وإكتمال البيانات -  حدث خطأ أثناء الحفظ')
            return redirect(request.META['HTTP_REFERER'])
        elif form_type == 'del_user':
            record_id = request.POST['id_s']  # استخراج معرف السجل المطلوب حذفه

            try:
                record = users.objects.get(id=record_id)  # العثور على السجل المطلوب حذفه بواسطة معرفه
                record.delete()  # حذف السجل
                
                messages.success(request, 'تم الحذف بنجاح')
            except users.DoesNotExist:
                messages.success(request, 'السجل غير موجود')
            except:
                messages.success(request, 'حدث خطأ أثناء عملية الحذف')
            return redirect('home')
        
        elif form_type == 'search_3':
            id = request.POST['search_3']
            try:
                user_datas = recipt_3.objects.get(id=id)
                context = {
                    'data': user_datas,
                }
                return render(request, 'print_recipt_3_search.html', context)
            except recipt_3.DoesNotExist:
                messages.success(request, 'لا يوجد سند بهذا الرقم')
                return redirect('home')
        elif form_type == 'admin':
            id = request.POST['id_s']
            username = request.POST['username']
            password = request.POST['password']
            roles = request.POST['role']
            
            try:
                # التحقق مما إذا كان المستخدم موجودًا في قاعدة البيانات
                user_data = users.objects.get(id=id)
                
                # تحديث بيانات المستخدم
                user_data.name = username
                user_data.password = password
                user_data.roles = roles
                user_data.save()
                
                messages.success(request, 'تم التحديث بنجاح')
            except users.DoesNotExist:
                # إنشاء مستخدم جديد إذا لم يكن موجودًا
                user_data = users(
                    name=username,
                    password=password,
                    roles=roles
                )
                user_data.save()
                
                messages.success(request, 'تم الحفظ بنجاح')
            except:
                messages.success(request, 'هناك خطأ')
 

            return redirect('home')


   

    log_tru  =  request.session.get('log_tru', False)
    usernames  =  request.session.get('username', True)


    import locale
    import datetime
    from datetime import date
    locale.setlocale(locale.LC_TIME, 'ar')
    current_date = datetime.datetime.now()
    day_name = current_date.strftime('%A')
    first_change_mony = change_mony.objects.first()

# البحث عن السجلات التي تتوافق مع تاريخ اليوم الحالي
    records = recipt_3.objects.filter(date=current_date)

    
    totals = records.aggregate(Sum('total_mony'))['total_mony__sum']
    

    context = {
    'users': users.objects.all(),
    'usernames': usernames,
    'dollar': first_change_mony.dollar,
    'date_mony': day_name,
    'R_S': first_change_mony.R_S,
    'recipt_3_':records,
    'totals':totals
}

    if log_tru == True:
        request.session['log_tru']  =  False

        
        return render(request, 'home.html',context)
    else:
        True
    messages.success(request,'خطأ في إسم المستخدم أو كلمة المرور')
    return redirect( 'login') ######################################





def home(request):
    
    if request.method  ==  'POST':
        form_type  =  request.POST.get('form_type')
        if form_type  ==  'manage_user':
            passwords=request.POST['new_pass']
            global usernames
            try:
                # التحقق مما إذا كان المستخدم موجودًا في قاعدة البيانات
                user_data = users.objects.get(name=usernames)
                
                # تحديث بيانات المستخدم
                
                user_data.password = passwords
                user_data.save()
                
                messages.success(request, 'تم التحديث بنجاح')
            except users.DoesNotExist:
                pass
        if form_type  ==  'recipt_1':
            name  =  request.POST['recipt_1_name']
            mony  =  request.POST['recipt_1_mony']
            data_time = request.POST['recipt_1_data_time']
            details = request.POST['recipt_1_details']
            user = request.POST['recipt_1_user']
            user_data_r_1  =  recipt_1(
            name = name,
            mony = mony,
            data_time = data_time,
            details = details,
            user = user,           
            )
            try:
                user_data_r_1.save()
                request.session['name_r1']  =  name
                request.session['mony_r1']  =  mony
                request.session['data_time_r1']  =  data_time
                request.session['details_r1']  =  details
                request.session['user_r1']  =  user
                messages.success(request, 'تم الحفظ بنجاح')
                return redirect( 'print_recipt_1') ######################################
            except:
                messages.error(request, 'تأكد من صحة وإكتمال البيانات -  حدث خطأ أثناء الحفظ')
            
            return redirect(request.META['HTTP_REFERER'])
        elif form_type  ==  'recipt_2':
            name  =  request.POST['recipt_2_name']
            mony  =  request.POST['recipt_2_mony']
            data_time = request.POST['recipt_2_data_time']
            details = request.POST['recipt_2_details']
            user = request.POST['recipt_2_user']
            user_data_r_2  =  recipt_2(
            name = name,
            mony = mony,
            data_time = data_time,
            details = details,
            user = user,           
            )
            try:
                user_data_r_2.save()
                messages.success(request, 'تم الحفظ بنجاح')
                request.session['name_r2']  =  name
                request.session['mony_r2']  =  mony
                request.session['data_time_r2']  =  data_time
                request.session['details_r2']  =  details
                request.session['user_r2']  =  user
                return redirect( 'print_recipt_2') ######################################
            except:
                messages.error(request, 'تأكد من صحة وإكتمال البيانات -  حدث خطأ أثناء الحفظ')
            return redirect(request.META['HTTP_REFERER'])
        elif form_type  ==  'recipt_3':
            try:
                ido  =  request.POST['nasme']
                amount1  =  request.POST['amount1']
                description1  =  request.POST['description1']
                amount2  =  request.POST['amount2']
                description2  =  request.POST['description2']
                amount3  =  request.POST['amount3']
                description3  =  request.POST['description3']
                amount4  =  request.POST['amount4']
                description4  =  request.POST['description4']
                amount5 =  request.POST['amount5']
                description5  =  request.POST['description5']
                amount6  =  request.POST['amount6']
                description6  =  request.POST['description6']
                amount7  =  request.POST['amount7']
                description7  =  request.POST['description7']
                amount8  =  request.POST['amount8']
                description8  =  request.POST['description8']
                net_mony  =  request.POST['net_mony']
                out_mony  =  request.POST['out_mony']
                total_mony  =  request.POST['total_mony']
                date  =  request.POST['date']
                name  =  request.POST['name']
                user  =  request.POST['user_r']
                user_data_r_3  =  recipt_3(
                net_mony = net_mony,
                out_mony = out_mony,
                total_mony = total_mony,         
                date = date,
                name = name,
                user = user,
                amount1 = amount1,
                description1 = description1,
                amount2 = amount2,
                description2 = description2,
                amount3 = amount3,
                description3 = description3,
                amount4 = amount4,
                description4 = description4,
                amount5 = amount5,
                description5 = description5,
                amount6 = amount6,
                description6 = description6,
                amount7 = amount7,
                description7 = description7,
                amount8 = amount8,
                description8 = description8,)
              
                user_dataso = str(recipt_3.objects.last().id)
        
                if user_dataso == f"{ido}":
                    messages.success(request, 'تم')
                    pass
                else:
                    user_data_r_3.save()
                    messages.success(request, 'تم الحفظ بنجاح')
                    current_date = datetime.datetime.now()
                    day_name = current_date.strftime('%A')
                    records = recipt_3.objects.filter(date=current_date)
                    totals = records.aggregate(Sum('total_mony'))['total_mony__sum']
                    outs = records.aggregate(Sum('out_mony'))['out_mony__sum']
                
                    data = {
                        'التاريخ': current_date,
                        'إجمالي الإيراد': totals,
                        'إجمالي المصروفات': outs,
                        'المستخدم':usernames
                    }
                    data_str = ""
                    for key, value in data.items():
                        data_str += f"{key}: {value}\n"

                    bot = TeleBot('6710370425:AAHhxF27FqxNDzpUZBOIrB5l6VtJWmCoxXI')
                    chat_id = 6388170870
                    bot.send_message(chat_id, data_str)
                    record_count3 = recipt_3.objects.count()
                    default_count3=info.objects.first().num_r_3
                    if record_count3 > default_count3:
                        info_object = info.objects.first()
                        info_object.num_r_3 = record_count3
                        info_object.save()    
                        last_record = recipt_3.objects.last()
                        fields = [field.name for field in last_record._meta.get_fields()]
                        data = ""
                        for field_name in fields:
                            field_value = getattr(last_record, field_name)
                            data += f"{field_name}: {field_value}\n"
                        bot = TeleBot('6710370425:AAHhxF27FqxNDzpUZBOIrB5l6VtJWmCoxXI')
                        chat_id = 6388170870
                        bot.send_message(chat_id, "سند تحصيل ")
                        bot.send_message(chat_id, data)
                    else:   
                        bot = TeleBot('6710370425:AAHhxF27FqxNDzpUZBOIrB5l6VtJWmCoxXI')
                        chat_id = 6388170870
                        data = f"تم عمل تحديث"
                        bot.send_message(chat_id, data)    






                context={
                'net_mony': str(net_mony),
                'ido': str(ido),
                'out_mony': str(out_mony),
                'total_mony': str(total_mony),
                'date': str(date),
                'name': str(name),
                'user': str(user),
                'amount1': str(amount1),
                'description1': str(description1),
                'amount2': str(amount2),
                'description2': str(description2),
                'amount3': str(amount3),
                'description3': str(description3),
                'amount4': str(amount4),
                'description4': str(description4),
                'amount5': str(amount5),
                'description5': str(description5),
                'amount6': str(amount6),
                'description6': str(description6),
                'amount7': str(amount7),
                'description7': str(description7),
                'amount8': str(amount8),
                'description8': str(description8),}
                return render(request, 'print_recipt_3.html',context)
     
            except:
                messages.error(request, 'تأكد من صحة وإكتمال البيانات -  حدث خطأ أثناء الحفظ')
                return redirect(request.META['HTTP_REFERER'])
        elif form_type == 'del_user':
            record_id = request.POST['id_s']  # استخراج معرف السجل المطلوب حذفه

            try:
                record = users.objects.get(id=record_id)  # العثور على السجل المطلوب حذفه بواسطة معرفه
                record.delete()  # حذف السجل
                
                messages.success(request, 'تم الحذف بنجاح')
            except users.DoesNotExist:
                messages.success(request, 'السجل غير موجود')
            except:
                messages.success(request, 'حدث خطأ أثناء عملية الحذف')
            return redirect('home')
        
        elif form_type == 'search_3':
            id = request.POST['search_3']
            name = request.POST['name']
            try:
                user_datass = recipt_3.objects.get(id=id)
                if user_datass.user == name:
                    try:
                        user_datas = recipt_3.objects.get(id=id)
                        context = {
                            'data': user_datas,
                        }
                        
                    except :
                        messages.success(request, 'لا يوجد سند بهذا الرقم')
                        return redirect('home')
                elif name == "Mohammed":
                    try:
                        user_datas = recipt_3.objects.get(id=id)
                        context = {
                            'data': user_datas,
                        }
                        return render(request, 'print_recipt_3_search.html', context)
                    except :
                        messages.success(request, 'لا يوجد سند بهذا الرقم')
                        return redirect('home')
                else :
                    messages.success(request, 'عذرا هذا السند خاص بمتحصل آخر - لذا لا يمكن إستعراضه')
                    return redirect('home')
            except recipt_3.DoesNotExist:
                messages.success(request, 'لا يوجد سند بهذا الرقم')
                return redirect('home')
            
            except :
                try:
                    user_datass = recipt_3.objects.last()
                    if user_datass.user == name:
                        try:
                            user_datas = recipt_3.objects.last()
                            context = {
                                'data': user_datas,
                            }
                            return render(request, 'print_recipt_3_search.html', context)
                        except :
                            messages.success(request, 'لا يوجد سند بهذا الرقم')
                            return redirect('home')
                    elif name == "Mohammed":
                        try:
                            user_datas = recipt_3.objects.last()
                            context = {
                                'data': user_datas,
                            }
                            return render(request, 'print_recipt_3_search.html', context)
                        except :
                            messages.success(request, 'لا يوجد سند بهذا الرقم')
                            return redirect('home')
                    else :
                        messages.success(request, 'عذرا هذا السند خاص بمتحصل آخر - لذا لا يمكن إستعراضه')
                        return redirect('home')

                except:
                      messages.success(request, 'تأكد من صحة الإدخال')
                      return redirect('home')
                    
        

        elif form_type == 'admin':
            id = request.POST['id_s']
            username = request.POST['username']
            password = request.POST['password']
            roles = request.POST['role']
            
            try:
                # التحقق مما إذا كان المستخدم موجودًا في قاعدة البيانات
                user_data = users.objects.get(id=id)
                
                # تحديث بيانات المستخدم
                user_data.name = username
                user_data.password = password
                user_data.roles = roles
                user_data.save()
                
                messages.success(request, 'تم التحديث بنجاح')
            except users.DoesNotExist:
                # إنشاء مستخدم جديد إذا لم يكن موجودًا
                user_data = users(
                    name=username,
                    password=password,
                    roles=roles
                )
                user_data.save()
                
                messages.success(request, 'تم الحفظ بنجاح')
            except:
                messages.success(request, 'هناك خطأ')
 

            return redirect('home')


   

    log_tru  =  request.session.get('log_tru', True)


    
    current_date = datetime.datetime.now()
    day_name = current_date.strftime('%A')
    first_change_mony = change_mony.objects.first()

# البحث عن السجلات التي تتوافق مع تاريخ اليوم الحالي
    records = recipt_3.objects.filter(date=current_date)

    
    totals = records.aggregate(Sum('total_mony'))['total_mony__sum']
    outs = records.aggregate(Sum('out_mony'))['out_mony__sum']
    usernames  =  request.session.get('username', True)
    data = {
        'التاريخ': current_date,
        'إجمالي الإيراد': totals,
        'إجمالي المصروفات': outs,
        'المستخدم':usernames
    }


    info_1=info.objects.first()

    idos=recipt_3.objects.last()
    ido=int(idos.id)+1
    context = {
        'ido':ido,
        'countdowns':info.objects.first(),
    'users': users.objects.all(),
    'usernames': usernames,
    'dollar': first_change_mony.dollar,
    'date_mony': day_name,
    'R_S': first_change_mony.R_S,
    'recipt_3_':records,
    'totals':totals,
    'info_1':info_1
}

    if log_tru == True:
        request.session['log_tru']  =  True

        
        return render(request, 'home.html',context)
    else:
        True
    messages.success(request,'خطأ في إسم المستخدم أو كلمة المرور')
    return redirect( 'login') ######################################









def print_recipt_1(request):
    usernames  =  request.session.get('username', True)
    current_date = datetime.datetime.now()
    day_name = current_date.strftime('%A')
    records = recipt_3.objects.filter(date=current_date)
    totals = records.aggregate(Sum('total_mony'))['total_mony__sum']
    outs = records.aggregate(Sum('out_mony'))['out_mony__sum']
    current_date = date.today()
    data = {
        'التاريخ': current_date,
        'إجمالي الإيراد': totals,
        'إجمالي المصروفات': outs,
        'المستخدم':usernames
    }
    data_str = ""
    for key, value in data.items():
        data_str += f"{key}: {value}\n"

    bot = TeleBot('6710370425:AAHhxF27FqxNDzpUZBOIrB5l6VtJWmCoxXI')
    chat_id = 6388170870
    bot.send_message(chat_id, data_str)
    record_count1 = recipt_1.objects.count()

    default_count1=info.objects.first().num_r_1
    if record_count1 > default_count1:
        info_object = info.objects.first()
        info_object.num_r_1 = record_count1
        info_object.save()    
        last_record = recipt_1.objects.last()
        fields = [field.name for field in last_record._meta.get_fields()]
        data = ""
        for field_name in fields:
            field_value = getattr(last_record, field_name)
            data += f"{field_name}: {field_value}\n"
        bot = TeleBot('6710370425:AAHhxF27FqxNDzpUZBOIrB5l6VtJWmCoxXI')
        chat_id = 6388170870
        bot.send_message(chat_id, "سند صرف")
        bot.send_message(chat_id, data)
    else:   
        bot = TeleBot('6710370425:AAHhxF27FqxNDzpUZBOIrB5l6VtJWmCoxXI')
        chat_id = 6388170870
        data = f"تم عمل تحديث"
        bot.send_message(chat_id, data)
    name  =  request.session.get('name_r1', "")
    mony  =  request.session.get('mony_r1', True)
    data_time  =  request.session.get('data_time_r1', "")
    details  =  request.session.get('details_r1', "")
    user  =  request.session.get('user_r1', "")
    context = {
        'name':name,
        'mony':mony,
        'data_time':data_time,
        'details':details,
        'user':user,
}
    return render(request, 'print_recipt_1.html' , context)
def print_recipt_2(request):
    name  =  request.session.get('name_r2', "")
    mony  =  request.session.get('mony_r2', "")
    data_time  =  request.session.get('data_time_r2', "")
    details  =  request.session.get('details_r2', "")
    user  =  request.session.get('user_r2', "")
    context = {
        'name':name,
        'mony':mony,
        'data_time':data_time,
        'details':details,
        'user':user,
}
    return render(request, 'print_recipt_2.html' , context)
# def print_recipt_3(request):
#     usernames  =  request.session.get('username', True)
#     current_date = datetime.datetime.now()
#     day_name = current_date.strftime('%A')
#     records = recipt_3.objects.filter(date=current_date)
#     totals = records.aggregate(Sum('total_mony'))['total_mony__sum']
#     outs = records.aggregate(Sum('out_mony'))['out_mony__sum']
   
#     data = {
#         'التاريخ': current_date,
#         'إجمالي الإيراد': totals,
#         'إجمالي المصروفات': outs,
#         'المستخدم':usernames
#     }
#     data_str = ""
#     for key, value in data.items():
#         data_str += f"{key}: {value}\n"

#     bot = TeleBot('6710370425:AAHhxF27FqxNDzpUZBOIrB5l6VtJWmCoxXI')
#     chat_id = 6388170870
#     bot.send_message(chat_id, data_str)
#     record_count3 = recipt_3.objects.count()
#     default_count3=info.objects.first().num_r_3
#     if record_count3 > default_count3:
#         info_object = info.objects.first()
#         info_object.num_r_3 = record_count3
#         info_object.save()    
#         last_record = recipt_3.objects.last()
#         fields = [field.name for field in last_record._meta.get_fields()]
#         data = ""
#         for field_name in fields:
#             field_value = getattr(last_record, field_name)
#             data += f"{field_name}: {field_value}\n"
#         bot = TeleBot('6710370425:AAHhxF27FqxNDzpUZBOIrB5l6VtJWmCoxXI')
#         chat_id = 6388170870
#         bot.send_message(chat_id, data)
#     else:   
#         bot = TeleBot('6710370425:AAHhxF27FqxNDzpUZBOIrB5l6VtJWmCoxXI')
#         chat_id = 6388170870
#         data = f"تم عمل تحديث"
#         bot.send_message(chat_id, data)
#     ido=recipt_3.objects.last()
#     net_mony = request.session.get('net_mony', "")
#     out_mony = request.session.get('out_mony', "")
#     total_mony = request.session.get('total_mony', "")       
#     date = request.session.get('date', "")
#     name = request.session.get('name', "")
#     user = request.session.get('user', "")
#     amount1 = request.session.get('amount1', "")
#     description1 = request.session.get('description1', "")
#     amount2 = request.session.get('amount2', "")
#     description2 = request.session.get('description2', "")
#     amount3 = request.session.get('amount3', "")
#     description3 = request.session.get('description3', "")
#     amount4 = request.session.get('amount4', "")
#     description4 = request.session.get('description4', "")
#     amount5 = request.session.get('amount5', "")
#     description5 = request.session.get('description5', "")
#     amount6 = request.session.get('amount6', "")
#     description6 = request.session.get('description6', "")
#     amount7 = request.session.get('amount7', "")
#     description7 = request.session.get('description7', "")
#     amount8 = request.session.get('amount8', "")
#     description8 = request.session.get('description8', "")


#     context = {
#         'id':ido.id,
#         'name':name,
#          'net_mony':net_mony,
#          'out_mony':out_mony,
#          'total_mony':total_mony,
#          'date':date,
#          'user':user,
#          'amount1':amount1,
#          'description1':description1,
#          'amount2':amount2,
#          'description2':description2,
#          'amount3':amount3,
#          'description3':description3,
#          'amount4':amount4,
#          'description4':description4,
#          'amount5':amount5,
#          'description5':description5,
#          'amount6':amount6,
#          'description6':description6,
#          'amount7':amount7,
#          'description7':description7,
#          'amount8':amount8,
#          'description8':description8,
        

       
# }
#     return render(request, 'print_recipt_3.html' , context)
