from django.db import models

# Create your models here.
class users(models.Model):
    
    Roles=[('admin','admin'),
                 ('supervisor','supervisor'),
                 ('user','user')
                 ]
    branche=[('Main','Main'),
        ('Al-thawra','Al-thawra'),
                 ('Haddah','Haddah'),
                 ('Mathbah','Mathbah')
                 ]
    name=models.TextField(max_length=150)
    password = models.TextField(max_length=150)
    roles = models.CharField(max_length=200,choices=Roles,default=Roles[2])
    branch = models.CharField(max_length=200,choices=branche,default=Roles[0])
    def __str__(self):
        return (f"{self.name}")

class settings(models.Model):
    
    Roles=[('yes','yes'),
                 ('no','no'),
                
                 ]

    maintenance_status = models.CharField(max_length=200,choices=Roles)
class recipt_1(models.Model):

    name=models.TextField(max_length=150)
    mony = models.FloatField(max_length=10)
    data_time = models.CharField(max_length=200)
    details = models.CharField(max_length=250)
    user = models.CharField(max_length=250)
class recipt_2(models.Model):

    name=models.TextField(max_length=150)
    mony = models.FloatField(max_length=10)
    data_time = models.CharField(max_length=200)
    details = models.CharField(max_length=250)
    user = models.CharField(max_length=250)
class change_mony(models.Model):

    date_mony = models.DateTimeField(auto_now_add=True)
    dollar = models.FloatField(max_length=10)
    R_S = models.FloatField(max_length=10)
class info(models.Model):
    num_r_1 = models.FloatField(max_length=10)
    num_r_2 = models.FloatField(max_length=10)
    num_r_3 = models.FloatField(max_length=10)
    countdown = models.FloatField(max_length=10,default=10)
    Generalization_add = models.CharField(max_length=10,default='none')
    Generalization_detail = models.CharField(max_length=2000,default='none')




class recipt_3(models.Model):
    amount1 = models.DecimalField(max_digits=10, decimal_places=2)
    description1 = models.CharField(max_length=100)
    amount2 = models.DecimalField(max_digits=10, decimal_places=2)
    description2 = models.CharField(max_length=100)
    amount3 = models.DecimalField(max_digits=10, decimal_places=2)
    description3 = models.CharField(max_length=100)
    amount4 = models.DecimalField(max_digits=10, decimal_places=2)
    description4 = models.CharField(max_length=100)
    amount5 = models.DecimalField(max_digits=10, decimal_places=2)
    description5 = models.CharField(max_length=100)
    amount6 = models.DecimalField(max_digits=10, decimal_places=2)
    description6 = models.CharField(max_length=100)
    amount7 = models.DecimalField(max_digits=10, decimal_places=2)
    description7 = models.CharField(max_length=100)
    amount8 = models.DecimalField(max_digits=10, decimal_places=2)
    description8 = models.CharField(max_length=100)
    net_mony = models.DecimalField(max_digits=10, decimal_places=2)
    out_mony = models.DecimalField(max_digits=10, decimal_places=2)
    total_mony = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateField()
    name = models.CharField(max_length=100)
    user = models.CharField(max_length=100)

    def __str__(self):
        return (f" {self.id} {self.user} {self.date}")  # You can choose any field to represent the object as a string

