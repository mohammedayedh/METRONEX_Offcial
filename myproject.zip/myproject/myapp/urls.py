from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.login, name='login'),
    path('logout', views.logout, name='logout'),
    path('home/', views.home, name='home'),
    path('admin_home/', views.admin_home, name='admin_home'),
    path('print_recipt_1/', views.print_recipt_1, name='print_recipt_1'),
    path('print_recipt_2/', views.print_recipt_2, name='print_recipt_2'),


] 
