function showWarning() {
    const warningContainer = document.getElementById('warningContainer');
    warningContainer.classList.add('show');
  }

  function hideWarning() {
    const warningContainer = document.getElementById('warningContainer');
    warningContainer.classList.remove('show');
  }
              
              var email="Mohammed";
              var password=1234;
              var user_email=document.getElementById("input_1").value;
              var user_pass=document.getElementById("input_2").value;
              function myfunction(){
                  if (email == document.getElementById("input_1").value) {
                      if (password==document.getElementById("input_2").value ) {
                        showLoading()
                        setTimeout(openNewPage, 3000);

                         
                      } else { // كلمة المرور  خاطئ
                          showWarning()
                      }
                      
                  } else {// إسم المستخدم خاطئ
                      
                      showWarning()
                  }
                  function openNewPage() {
                    window.open("/home", "_self");
                }
              }
              function showLoading() {
                const loadingContainer = document.getElementById('loadingContainer');
                loadingContainer.classList.add('show');
                setTimeout(hideLoading, 3000); // تأخير الإخفاء لمدة 3 ثواني (يمكنك تعديل الرقم حسب الحاجة)
              }
          
              function hideLoading() {
                const loadingContainer = document.getElementById('loadingContainer');
                loadingContainer.classList.remove('show');
              }